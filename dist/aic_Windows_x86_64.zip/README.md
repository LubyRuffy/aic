# aic
ai client with ollama
